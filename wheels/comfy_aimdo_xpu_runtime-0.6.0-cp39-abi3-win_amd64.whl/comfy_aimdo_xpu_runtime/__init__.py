"""Co-installable AIMDO XPU runtime provider."""

from .provider import get_manifest

__all__ = ["get_manifest"]
