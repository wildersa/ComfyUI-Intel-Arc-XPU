"""Lightweight metadata entry point for the OmniXPU bootstrap."""

from __future__ import annotations

import json
from importlib.resources import files


def get_manifest():
    path = files(__package__).joinpath("provider.json")
    return json.loads(path.read_text(encoding="utf-8"))
