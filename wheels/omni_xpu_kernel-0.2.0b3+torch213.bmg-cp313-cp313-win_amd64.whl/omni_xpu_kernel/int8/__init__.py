"""
INT8 Quantization and Linear Operations for Intel XPU.

Provides high-performance INT8 inference kernels matching comfy-kitchen's INT8 API:
- quantize_int8_tensorwise: Tensor-wise INT8 quantization (single scale)
- quantize_int8_rowwise: Per-row INT8 quantization (activation path)
- dequantize_int8_simple: INT8 dequantization with scale
- dequantize_int8_simple_dtype: INT8 dequantization with output dtype
- int8_linear: Dynamic INT8 linear layer (quant activation + INT8 GEMM + rescale)
- int8_linear_prequantized: Scaled INT8 linear for a prequantized activation
- mm_int8: Raw INT8 matrix multiplication (s8×s8→s32)
- quantize_int8_convrot_weight: Offline ConvRot weight rotation + quantization
- dequantize_int8_convrot_weight: ConvRot dequantization with inverse rotation

Performance path:
    Native C++ (oneDNN s8 matmul + ESIMD fusion) > Python reference fallback

Example:
    from omni_xpu_kernel import int8

    # Quantize weight offline
    w_int8, w_scale = int8.quantize_int8_tensorwise(weight)

    # INT8 linear inference
    output = int8.int8_linear(x, w_int8, w_scale, bias=bias, out_dtype=torch.bfloat16)

    # Reuse one activation quantization across one or more linear calls
    x_int8, x_scale = int8.quantize_int8_rowwise(x)
    output = int8.int8_linear_prequantized(
        x_int8, x_scale, w_int8, w_scale, bias=bias,
        out_dtype=torch.bfloat16,
    )

    # With ConvRot
    output = int8.int8_linear(x, w_int8, w_scale, convrot=True, convrot_groupsize=256)
"""

import contextlib
import os
import sys
import threading
from typing import Optional, Tuple

import torch

from .. import _compile_meta as _meta

from .._compile_ops import (
    compile_op, fake_rowwise, fake_silu_mul, fake_silu_mul_rowwise,
    fake_swiglu_rowwise, fake_gelu_rowwise, fake_int8_linear,
    fake_prequantized, fake_w4a8_prequantized, fake_shared_input, fake_rotate_convrot,
)

from ._reference import (
    quantize_int8_tensorwise as _ref_quantize_int8_tensorwise,
    quantize_int8_rowwise as _ref_quantize_int8_rowwise,
    fused_silu_mul_quantize_rowwise as _ref_fused_silu_mul_quantize_rowwise,
    fused_silu_mul as _ref_fused_silu_mul,
    dequantize_int8_simple as _ref_dequantize_int8_simple,
    dequantize_int8_simple_dtype as _ref_dequantize_int8_simple_dtype,
    mm_int8 as _ref_mm_int8,
    int8_linear as _ref_int8_linear,
    int8_linear_prequantized as _ref_int8_linear_prequantized,
    int8_linear_shared_input as _ref_int8_linear_shared_input,
    quantize_int8_convrot_weight as _ref_quantize_int8_convrot_weight,
    dequantize_int8_convrot_weight as _ref_dequantize_int8_convrot_weight,
)


def _get_native():
    """Get the native INT8 module (returns None if unavailable)."""
    try:
        from .. import _load_extension

        mod = _load_extension()
        return getattr(mod, "int8", None)
    except (ImportError, AttributeError):
        return None


_allocation_context_factory = contextlib.nullcontext


def set_allocation_context_factory(factory) -> None:
    """Select the caller context used for persistent ConvRot cache creation."""
    global _allocation_context_factory
    if not callable(factory):
        raise TypeError("allocation context factory must be callable")
    _allocation_context_factory = factory


def _prepare_native_convrot_hadamard(native, exemplar, group_size, *, fp32=False):
    prepare = getattr(native, "prepare_convrot_hadamard", None)
    if prepare is None:
        return False
    with _allocation_context_factory():
        prepare(exemplar, group_size, fp32)
    return True


def prepare_convrot_hadamard(exemplar: torch.Tensor, group_size: int = 256,
                             *, fp32: bool = False) -> bool:
    """Prepare a persistent native matrix under the caller's allocation context."""
    native = _get_native()
    return (native is not None and
            _prepare_native_convrot_hadamard(native, exemplar, group_size,
                                             fp32=fp32))


def clear_convrot_hadamard_cache(device_index: int) -> int:
    """Synchronize one XPU device, then release its persistent ConvRot matrices."""
    if type(device_index) is not int or device_index < 0:
        raise ValueError("ConvRot cache device index must be nonnegative")
    native = _get_native()
    if native is None:
        return 0
    clear = getattr(native, "clear_convrot_hadamard_cache", None)
    if clear is None:
        raise RuntimeError("native ConvRot cache release is unavailable")
    torch.xpu.synchronize(device_index)
    return int(clear(device_index))


def _native_rotate_convrot(native, x, group_size):
    _prepare_native_convrot_hadamard(native, x, group_size)
    return native.rotate_convrot(x, group_size)


def _apply_input_act(
    x: torch.Tensor, input_act: Optional[str]
) -> torch.Tensor:
    if input_act in (None, "none"):
        return x
    if input_act == "gelu_tanh":
        return torch.nn.functional.gelu(x, approximate="tanh")
    if input_act == "swiglu":
        gate, up = x.chunk(2, dim=-1)
        return torch.nn.functional.silu(gate).mul_(up)
    if input_act == "situ":
        hidden, gate = x.chunk(2, dim=-1)
        gated = gate.div(4.0).tanh_().mul_(4.0).mul_(torch.sigmoid(gate))
        return hidden.div(25.0).tanh_().mul_(25.0).mul_(gated)
    raise ValueError(
        f"unsupported input_act: {input_act!r} "
        "(expected one of ['gelu_tanh', 'none', 'situ', 'swiglu'])"
    )


_h3_swiglu_trace_logged = False
_h3_low_peak_trace_logged = False
_h3_low_peak_convrot_trace_logged = False
_int8_linear_tiling_trace_logged = False

# A single very-large dynamic INT8 matmul keeps its full MxK quantized
# activation live beside the unavoidable MxN output.  Under resident model
# weights this can exhaust device memory or Level Zero resources.  Bound each
# dispatch by its quantized-input plus output span; rowwise quantization makes
# rows independent, so tiling preserves the quantization and output contracts.
_INT8_LINEAR_TILING_MIN_QUANTIZED_BYTES = 512 * 1024**2
_INT8_LINEAR_TILING_MIN_LIVE_BYTES = 2 * 1024**3
_INT8_LINEAR_TILING_CHUNK_BYTES = 512 * 1024**2
_INT8_LINEAR_TILING_ROW_ALIGNMENT = 4096


def _int8_linear_chunk_rows(
    input_features: int, output_features: int, element_size: int
) -> int:
    """Return a row tile from the operator's per-row live-byte contract."""
    row_bytes = input_features + 4 + output_features * element_size
    rows = max(1, _INT8_LINEAR_TILING_CHUNK_BYTES // row_bytes)
    if rows >= _INT8_LINEAR_TILING_ROW_ALIGNMENT:
        rows = (
            rows // _INT8_LINEAR_TILING_ROW_ALIGNMENT
            * _INT8_LINEAR_TILING_ROW_ALIGNMENT
        )
    return rows


def _can_tile_int8_linear(
    x: torch.Tensor,
    native,
    weight: torch.Tensor,
    out_dtype: torch.dtype,
) -> bool:
    """Select bounded row tiling from the operator contract, not model identity."""
    if (
        native is None
        or not hasattr(native, "quantize_int8_rowwise_fused")
        or not hasattr(native, "int8_linear_prequantized_out")
        or not isinstance(x, torch.Tensor)
        or x.device.type != "xpu"
        or x.dtype not in (torch.float16, torch.bfloat16)
        or x.ndim < 1
        or x.shape[-1] <= 0
        or x.requires_grad
        or not isinstance(weight, torch.Tensor)
        or weight.ndim != 2
        or weight.shape[0] <= 0
        or weight.shape[1] != x.shape[-1]
        or weight.device != x.device
        or weight.dtype != torch.int8
        or out_dtype not in (torch.float32, torch.float16, torch.bfloat16)
    ):
        return False
    element_size = 4 if out_dtype == torch.float32 else 2
    rows = x.numel() // x.shape[-1]
    chunk_rows = _int8_linear_chunk_rows(
        x.shape[-1], weight.shape[0], element_size
    )
    quantized_activation_bytes = rows * (x.shape[-1] + 4)
    output_bytes = rows * weight.shape[0] * element_size
    return bool(
        rows > chunk_rows
        and quantized_activation_bytes
        >= _INT8_LINEAR_TILING_MIN_QUANTIZED_BYTES
        and quantized_activation_bytes + output_bytes
        >= _INT8_LINEAR_TILING_MIN_LIVE_BYTES
    )


def _tile_int8_linear(
    x: torch.Tensor,
    native,
    weight: torch.Tensor,
    weight_scale: torch.Tensor,
    bias: Optional[torch.Tensor],
    out_dtype: torch.dtype,
    dtype_code: int,
) -> torch.Tensor:
    """Quantize and project independent row tiles into one final output."""
    global _int8_linear_tiling_trace_logged

    input_shape = tuple(x.shape)
    rows = x.numel() // x.shape[-1]
    output_features = weight.shape[0]
    element_size = 4 if out_dtype == torch.float32 else 2
    chunk_rows = _int8_linear_chunk_rows(
        x.shape[-1], output_features, element_size
    )
    x_2d = x.reshape(rows, x.shape[-1])
    output_2d = torch.empty(
        (rows, output_features), device=x.device, dtype=out_dtype
    )
    for start in range(0, rows, chunk_rows):
        stop = min(start + chunk_rows, rows)
        chunk = x_2d[start:stop].contiguous()
        x_int8, x_scale = native.quantize_int8_rowwise_fused(chunk)
        output_chunk = output_2d[start:stop]
        native.int8_linear_prequantized_out(
            x_int8,
            x_scale,
            weight,
            weight_scale,
            bias,
            dtype_code,
            output_chunk,
        )
        del output_chunk, x_scale, x_int8, chunk

    if (
        not _int8_linear_tiling_trace_logged
        and os.environ.get("OMNIXPU_INT8_TILING_TRACE") == "1"
    ):
        print(
            "[OmniXPU] bounded int8_linear: "
            f"input={input_shape} output_features={output_features} "
            f"chunk_rows={chunk_rows}",
            flush=True,
        )
        _int8_linear_tiling_trace_logged = True

    return output_2d.reshape(*input_shape[:-1], output_features)

# The failing 720-class/15s allocation is a single 2.671 GiB BF16 H3 SwiGLU
# output.  Keep established shorter sequences on the faster whole-tensor route
# and stream rows only once that otherwise-unavoidable activation crosses 2 GiB.
_H3_LOW_PEAK_MIN_ACTIVATION_BYTES = 2 * 1024**3
_H3_LOW_PEAK_MIN_ROTATION_BYTES = 1024**3
_H3_LOW_PEAK_CHUNK_BYTES = 256 * 1024**2
_H3_LOW_PEAK_ROW_ALIGNMENT = 4096
_H3_SWIGLU_INPUT_FEATURES = 28672
_H3_SWIGLU_OUTPUT_FEATURES = 14336
_H3_FFN_DOWN_FEATURES = 5376
_H3_ATTN_OUTPUT_INPUT_FEATURES = 7168
_H3_ATTN_OUTPUT_FEATURES = 5376


def _is_supported_h3_swiglu_target() -> bool:
    """Require the BMG package/core pair used for H3 tuning."""
    try:
        from .. import __xpu_target__, core_aot_target

        return __xpu_target__ == "bmg" and core_aot_target() == "bmg"
    except (ImportError, RuntimeError):
        return False


def _can_fuse_h3_swiglu(
    x: torch.Tensor,
    native,
    weight: torch.Tensor,
    convrot: bool,
    convrot_groupsize: int,
    input_act: Optional[str],
) -> bool:
    """Match the structural BF16 H3 SwiGLU-to-G256 boundary."""
    return bool(
        input_act == "swiglu"
        and convrot
        and convrot_groupsize == 256
        and _is_supported_h3_swiglu_target()
        and native is not None
        and hasattr(native, "fused_silu_mul_exact_bf16")
        and isinstance(x, torch.Tensor)
        and x.device.type == "xpu"
        and x.dtype == torch.bfloat16
        and x.ndim == 2
        and x.shape[0] > 0
        and x.shape[1] > 0
        and x.shape[1] % 2 == 0
        and (x.shape[1] // 2) % convrot_groupsize == 0
        and x.is_contiguous()
        and not x.requires_grad
        and isinstance(weight, torch.Tensor)
        and weight.device == x.device
        and weight.dtype == torch.int8
        and weight.ndim == 2
        and weight.shape[1] == x.shape[1] // 2
    )


def _apply_h3_swiglu_exact(x: torch.Tensor, native) -> torch.Tensor:
    """Preserve PyTorch's BF16 SiLU and product materialization boundaries."""
    global _h3_swiglu_trace_logged

    gate, up = x.chunk(2, dim=-1)
    output = native.fused_silu_mul_exact_bf16(gate, up)
    if (
        not _h3_swiglu_trace_logged
        and os.environ.get("OMNIXPU_H3_SWIGLU_TRACE") == "1"
    ):
        print(
            "[OmniXPU] H3 exact SwiGLU route: "
            f"input={tuple(x.shape)} input_stride={tuple(x.stride())} "
            f"gate_stride={tuple(gate.stride())}",
            flush=True,
        )
        _h3_swiglu_trace_logged = True
    return output


def _h3_low_peak_chunk_rows(columns: int) -> int:
    """Bound one BF16 chunk while retaining the tuned rowwise threshold."""
    rows = _H3_LOW_PEAK_CHUNK_BYTES // (columns * 2)
    rows = rows // _H3_LOW_PEAK_ROW_ALIGNMENT * _H3_LOW_PEAK_ROW_ALIGNMENT
    return max(_H3_LOW_PEAK_ROW_ALIGNMENT, rows)


def _can_stream_h3_swiglu(
    x: torch.Tensor,
    native,
    weight: torch.Tensor,
    bias: Optional[torch.Tensor],
    out_dtype: torch.dtype,
    convrot: bool,
    convrot_groupsize: int,
    input_act: Optional[str],
) -> bool:
    """Match the exact H3 FFN-down boundary that needs bounded peak memory."""
    if not _can_fuse_h3_swiglu(
        x,
        native,
        weight,
        convrot,
        convrot_groupsize,
        input_act,
    ):
        return False
    activation_bytes = (
        x.shape[0] * (x.shape[1] // 2) * x.element_size()
    )
    return bool(
        x.shape[1] == _H3_SWIGLU_INPUT_FEATURES
        and weight.shape
        == (_H3_FFN_DOWN_FEATURES, _H3_SWIGLU_OUTPUT_FEATURES)
        and bias is None
        and out_dtype == torch.bfloat16
        and activation_bytes >= _H3_LOW_PEAK_MIN_ACTIVATION_BYTES
        and hasattr(native, "rotate_convrot")
        and hasattr(native, "quantize_int8_rowwise_fused")
        and hasattr(native, "int8_linear_prequantized_out")
    )


def _stream_h3_swiglu_int8_linear(
    x: torch.Tensor,
    native,
    weight: torch.Tensor,
    weight_scale: torch.Tensor,
    dtype_code: int,
) -> torch.Tensor:
    """Run exact H3 FFN-down row chunks into one final output allocation."""
    global _h3_low_peak_trace_logged

    rows = x.shape[0]
    columns = x.shape[1] // 2
    chunk_rows = _h3_low_peak_chunk_rows(columns)
    output = torch.empty(
        (rows, weight.shape[0]), device=x.device, dtype=torch.bfloat16
    )
    for start in range(0, rows, chunk_rows):
        stop = min(start + chunk_rows, rows)
        chunk = x[start:stop]
        gate, up = chunk.chunk(2, dim=-1)
        activated = native.fused_silu_mul_exact_bf16(gate, up)
        rotated = _native_rotate_convrot(native, activated, 256)
        x_int8, x_scale = native.quantize_int8_rowwise_fused(rotated)
        output_chunk = output[start:stop]
        native.int8_linear_prequantized_out(
            x_int8,
            x_scale,
            weight,
            weight_scale,
            None,
            dtype_code,
            output_chunk,
        )
        # Do not retain the previous chunk while launching the next producer.
        # PyTorch's XPU allocator records stream use before recycling storage.
        del (
            output_chunk,
            x_scale,
            x_int8,
            rotated,
            activated,
            up,
            gate,
            chunk,
        )

    if (
        not _h3_low_peak_trace_logged
        and os.environ.get("OMNIXPU_H3_LOW_PEAK_TRACE") == "1"
    ):
        print(
            "[OmniXPU] H3 low-peak FFN route: "
            f"input={tuple(x.shape)} output={tuple(output.shape)} "
            f"chunk_rows={chunk_rows}",
            flush=True,
        )
        _h3_low_peak_trace_logged = True
    return output


def _can_stream_h3_convrot(
    x: torch.Tensor,
    native,
    weight: torch.Tensor,
    bias: Optional[torch.Tensor],
    out_dtype: torch.dtype,
    convrot: bool,
    convrot_groupsize: int,
    input_act: Optional[str],
) -> bool:
    """Match the long-sequence H3 attention-output ConvRot boundary."""
    rotation_bytes = x.numel() * x.element_size()
    return bool(
        input_act in (None, "none")
        and convrot
        and convrot_groupsize == 256
        and _is_supported_h3_swiglu_target()
        and native is not None
        and isinstance(x, torch.Tensor)
        and x.device.type == "xpu"
        and x.dtype == torch.bfloat16
        and x.ndim == 2
        and x.shape[0] > 0
        and x.shape[1] == _H3_ATTN_OUTPUT_INPUT_FEATURES
        and x.is_contiguous()
        and not x.requires_grad
        and isinstance(weight, torch.Tensor)
        and weight.device == x.device
        and weight.dtype == torch.int8
        and tuple(weight.shape)
        == (_H3_ATTN_OUTPUT_FEATURES, _H3_ATTN_OUTPUT_INPUT_FEATURES)
        and weight.is_contiguous()
        and bias is None
        and out_dtype == torch.bfloat16
        and rotation_bytes >= _H3_LOW_PEAK_MIN_ROTATION_BYTES
        and hasattr(native, "rotate_convrot")
        and hasattr(native, "quantize_int8_rowwise_fused")
        and hasattr(native, "int8_linear_prequantized_out")
    )


def _stream_h3_convrot_int8_linear(
    x: torch.Tensor,
    native,
    weight: torch.Tensor,
    weight_scale: torch.Tensor,
    dtype_code: int,
) -> torch.Tensor:
    """Stream H3 attention-output rotation and quantization by rows."""
    global _h3_low_peak_convrot_trace_logged

    rows = x.shape[0]
    chunk_rows = _h3_low_peak_chunk_rows(x.shape[1])
    output = torch.empty(
        (rows, weight.shape[0]), device=x.device, dtype=torch.bfloat16
    )
    for start in range(0, rows, chunk_rows):
        stop = min(start + chunk_rows, rows)
        chunk = x[start:stop]
        rotated = _native_rotate_convrot(native, chunk, 256)
        x_int8, x_scale = native.quantize_int8_rowwise_fused(rotated)
        output_chunk = output[start:stop]
        native.int8_linear_prequantized_out(
            x_int8,
            x_scale,
            weight,
            weight_scale,
            None,
            dtype_code,
            output_chunk,
        )
        del output_chunk, x_scale, x_int8, rotated, chunk

    if (
        not _h3_low_peak_convrot_trace_logged
        and os.environ.get("OMNIXPU_H3_LOW_PEAK_TRACE") == "1"
    ):
        print(
            "[OmniXPU] H3 low-peak ConvRot route: "
            f"input={tuple(x.shape)} output={tuple(output.shape)} "
            f"chunk_rows={chunk_rows}",
            flush=True,
        )
        _h3_low_peak_convrot_trace_logged = True
    return output


def _can_fuse_gelu_tanh_quantize(
    x: torch.Tensor,
    native,
) -> bool:
    """Use only the BMG contracts where fused GELU beats materialization."""
    if (
        x.dtype not in (torch.float16, torch.bfloat16)
        or x.ndim < 2
        or x.shape[-1] <= 0
        or x.shape[-1] > 16384
        or not hasattr(native, "fused_gelu_tanh_quantize_rowwise")
        or not hasattr(native, "int8_linear_prequantized")
    ):
        return False
    try:
        from .. import __xpu_target__, core_aot_target

        if __xpu_target__ != "bmg" or core_aot_target() != "bmg":
            return False
    except (ImportError, RuntimeError):
        return False
    rows = x.numel() // x.shape[-1]
    return rows < 128


def _can_quantize_int8_convrot_g16_bmg(
    x: torch.Tensor,
    native,
    convrot: bool,
    convrot_groupsize: int,
) -> bool:
    """Return whether the captured BMG Boogu ConvRot route is exact."""
    if (
        native is None
        or not hasattr(native, "quantize_int8_convrot_g16_bmg")
        or not hasattr(native, "int8_linear_prequantized")
        or not convrot
        or convrot_groupsize != 16
        or x.device.type != "xpu"
        or x.dtype != torch.float16
        or x.ndim < 1
        or x.shape[-1] != 3360
        or not x.is_contiguous()
        or x.requires_grad
    ):
        return False
    rows = x.numel() // x.shape[-1]
    return rows in (109, 110, 4096, 4205, 4206)


def _can_pair_int8_convrot_g16_bmg(
    x: torch.Tensor,
    native,
    weight1: torch.Tensor,
    weight_scale1: torch.Tensor,
    weight2: torch.Tensor,
    weight_scale2: torch.Tensor,
    bias1: Optional[torch.Tensor],
    bias2: Optional[torch.Tensor],
    out_dtype: torch.dtype,
    convrot: bool,
    convrot_groupsize: int,
) -> bool:
    """Return whether the exact Boogu shared-up pair route applies."""
    if (
        not _can_quantize_int8_convrot_g16_bmg(
            x, native, convrot, convrot_groupsize
        )
        or not hasattr(native, "int8_linear_pair_prequantized")
        or out_dtype != torch.float16
        or bias1 is not None
        or bias2 is not None
    ):
        return False
    for weight, scale in (
        (weight1, weight_scale1),
        (weight2, weight_scale2),
    ):
        if (
            not isinstance(weight, torch.Tensor)
            or weight.device != x.device
            or weight.dtype != torch.int8
            or weight.shape != (13568, 3360)
            or not weight.is_contiguous()
            or not isinstance(scale, torch.Tensor)
            or scale.device != x.device
            or scale.numel() != 13568
        ):
            return False
    return True


_BMG_QKV_OUTPUT_FEATURES = (840, 3360)
_bmg_qkv_activation_cache = threading.local()


def _clear_bmg_qkv_activation_cache() -> None:
    """Drop the current thread's exact Boogu QKV activation cache."""
    _bmg_qkv_activation_cache.key = None
    _bmg_qkv_activation_cache.input = None
    _bmg_qkv_activation_cache.quantized = None
    _bmg_qkv_activation_cache.scale = None
    _bmg_qkv_activation_cache.remaining_hits = 0


def _can_cache_int8_convrot_g16_bmg(
    x: torch.Tensor,
    native,
    weight: torch.Tensor,
    weight_scale: torch.Tensor,
    bias: Optional[torch.Tensor],
    out_dtype: torch.dtype,
    convrot: bool,
    convrot_groupsize: int,
) -> bool:
    """Return whether the exact Boogu image Q/K/V cache contract applies."""
    if (
        not _can_quantize_int8_convrot_g16_bmg(
            x, native, convrot, convrot_groupsize
        )
        or out_dtype != torch.float16
        or bias is not None
        or not isinstance(weight, torch.Tensor)
        or weight.device != x.device
        or weight.dtype != torch.int8
        or weight.ndim != 2
        or weight.shape[1] != 3360
        or weight.shape[0] not in _BMG_QKV_OUTPUT_FEATURES
        or not weight.is_contiguous()
        or not isinstance(weight_scale, torch.Tensor)
        or weight_scale.device != x.device
        or weight_scale.numel() != weight.shape[0]
    ):
        return False
    return True


def _bmg_qkv_input_key(x: torch.Tensor) -> tuple:
    """Identify one activation on one XPU stream without synchronizing."""
    stream = torch.xpu.current_stream(x.device)
    is_inference = torch.is_inference(x)
    version = None if is_inference else x._version
    return (
        x.device.index,
        stream.stream_id,
        x.data_ptr(),
        x.storage_offset(),
        tuple(x.shape),
        tuple(x.stride()),
        x.dtype,
        is_inference,
        version,
    )


def _quantize_int8_convrot_g16_bmg_qkv(
    x: torch.Tensor,
    native,
    output_features: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Reuse the Q activation quantization for the following K and V calls.

    The exact Boogu attention sequence is one 3360-wide Q projection followed
    immediately by two 840-wide K/V projections from the same activation.
    Keeping the input alive prevents allocator pointer reuse; normal tensors
    also carry their mutation version in the key. Inference tensors do not
    expose a version counter, so their cache is deliberately limited to the
    two consecutive K/V hits and is cleared by every non-matching linear call.
    """
    key = _bmg_qkv_input_key(x)
    if (
        output_features == 840
        and getattr(_bmg_qkv_activation_cache, "key", None) == key
        and getattr(_bmg_qkv_activation_cache, "remaining_hits", 0) > 0
        and getattr(_bmg_qkv_activation_cache, "quantized", None) is not None
        and getattr(_bmg_qkv_activation_cache, "scale", None) is not None
    ):
        x_int8 = _bmg_qkv_activation_cache.quantized
        x_scale = _bmg_qkv_activation_cache.scale
        _bmg_qkv_activation_cache.remaining_hits -= 1
        if _bmg_qkv_activation_cache.remaining_hits == 0:
            _clear_bmg_qkv_activation_cache()
        return x_int8, x_scale

    _clear_bmg_qkv_activation_cache()
    x_int8, x_scale = native.quantize_int8_convrot_g16_bmg(x)
    if output_features == 3360:
        _bmg_qkv_activation_cache.key = key
        _bmg_qkv_activation_cache.input = x
        _bmg_qkv_activation_cache.quantized = x_int8
        _bmg_qkv_activation_cache.scale = x_scale
        _bmg_qkv_activation_cache.remaining_hits = 2
    return x_int8, x_scale


_KREA2_INPUT_SHAPE = (1, 4192, 6144)
_KREA2_OUTPUT_FEATURES = (1536, 6144, 16384)
_KREA2_MAXIMUM_CACHE_HITS = 3
_krea2_activation_cache = threading.local()


def _clear_krea2_activation_cache() -> None:
    """Drop the current thread's target-aligned Krea2 projection cache."""
    _krea2_activation_cache.key = None
    _krea2_activation_cache.input = None
    _krea2_activation_cache.quantized = None
    _krea2_activation_cache.scale = None
    _krea2_activation_cache.remaining_hits = 0


def _is_supported_krea2_cache_target() -> bool:
    """Require aligned package/core metadata for a validated XPU target."""
    try:
        from .. import __xpu_target__, core_aot_target

        return (
            __xpu_target__ in {"bmg", "ptl-h"}
            and core_aot_target() == __xpu_target__
        )
    except (ImportError, RuntimeError):
        return False


def _can_cache_krea2_int8_convrot(
    x: torch.Tensor,
    native,
    weight: torch.Tensor,
    weight_scale: torch.Tensor,
    bias: Optional[torch.Tensor],
    out_dtype: torch.dtype,
    convrot: bool,
    convrot_groupsize: int,
) -> bool:
    """Return whether the trace-proven Krea2 projection contract applies."""
    if (
        not _is_supported_krea2_cache_target()
        or native is None
        or not hasattr(native, "rotate_convrot")
        or not hasattr(native, "quantize_int8_rowwise_fused")
        or not hasattr(native, "int8_linear_prequantized")
        or not convrot
        or convrot_groupsize != 256
        or not isinstance(x, torch.Tensor)
        or x.device.type != "xpu"
        or x.dtype != torch.bfloat16
        or tuple(x.shape) != _KREA2_INPUT_SHAPE
        or not x.is_contiguous()
        or x.requires_grad
        or bias is not None
        or out_dtype != torch.bfloat16
        or not isinstance(weight, torch.Tensor)
        or weight.device != x.device
        or weight.dtype != torch.int8
        or weight.ndim != 2
        or weight.shape[1] != _KREA2_INPUT_SHAPE[-1]
        or weight.shape[0] not in _KREA2_OUTPUT_FEATURES
        or not weight.is_contiguous()
        or not isinstance(weight_scale, torch.Tensor)
        or weight_scale.device != x.device
        or weight_scale.dtype != torch.float32
        or weight_scale.numel() != weight.shape[0]
        or not weight_scale.is_contiguous()
    ):
        return False
    return True


def _quantize_krea2_int8_convrot(
    x: torch.Tensor,
    native,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Reuse the exact public G256 rotation and rowwise quantization.

    The canonical Krea2 workflow projects the same BF16 activation up to four
    immediately consecutive times.  The cache retains that activation, keys
    it by XPU stream and tensor identity, and permits at most three hits.
    Every non-matching public linear call clears the entry.
    """
    key = _bmg_qkv_input_key(x)
    if (
        getattr(_krea2_activation_cache, "key", None) == key
        and getattr(_krea2_activation_cache, "remaining_hits", 0) > 0
        and getattr(_krea2_activation_cache, "quantized", None) is not None
        and getattr(_krea2_activation_cache, "scale", None) is not None
    ):
        x_int8 = _krea2_activation_cache.quantized
        x_scale = _krea2_activation_cache.scale
        _krea2_activation_cache.remaining_hits -= 1
        if _krea2_activation_cache.remaining_hits == 0:
            _clear_krea2_activation_cache()
        return x_int8, x_scale

    _clear_krea2_activation_cache()
    rotated = _native_rotate_convrot(native, x, 256)
    x_int8, x_scale = native.quantize_int8_rowwise_fused(rotated)
    _krea2_activation_cache.key = key
    _krea2_activation_cache.input = x
    _krea2_activation_cache.quantized = x_int8
    _krea2_activation_cache.scale = x_scale
    _krea2_activation_cache.remaining_hits = _KREA2_MAXIMUM_CACHE_HITS
    return x_int8, x_scale


# =============================================================================
# Public API — dispatch to native or fallback to reference
# =============================================================================


@compile_op("quantize_int8_tensorwise", _meta.tensorwise)
def _quantize_tensorwise(
    x: torch.Tensor, stochastic_rounding: int = 0,
) -> Tuple[torch.Tensor, torch.Tensor]:
    return quantize_int8_tensorwise(x, None, stochastic_rounding)


@compile_op("quantize_int8_tensorwise_scaled", _meta.tensorwise_scaled)
def _quantize_tensorwise_scaled(
    x: torch.Tensor, scale: torch.Tensor, stochastic_rounding: int = 0,
) -> torch.Tensor:
    # Only q is returned across the opaque boundary. The public wrapper retains
    # the native scale's alias/conversion semantics with ordinary Torch ops.
    return quantize_int8_tensorwise(x, scale, stochastic_rounding)[0]


def quantize_int8_tensorwise(
    x: torch.Tensor,
    scale: Optional[torch.Tensor] = None,
    stochastic_rounding: int = 0,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Quantize tensor to INT8 with single tensorwise scale.

    Args:
        x: Input tensor of any shape.
        scale: Optional pre-computed scale. If None, computes absmax/127.
        stochastic_rounding: Seed for stochastic rounding. Disabled when <= 0.

    Returns:
        Tuple of (quantized_int8, scale):
            - quantized_int8: INT8 tensor with same shape
            - scale: Scalar float32 tensor
    """
    if torch.compiler.is_compiling():
        if scale is None:
            return torch.ops.omni_xpu.quantize_int8_tensorwise(x, stochastic_rounding)
        output_scale = scale.to(device=x.device, dtype=torch.float32)
        if stochastic_rounding <= 0 and x.dtype in (torch.float16, torch.bfloat16, torch.float32):
            output_scale = output_scale.contiguous()
        quantized = torch.ops.omni_xpu.quantize_int8_tensorwise_scaled(
            x, output_scale, stochastic_rounding
        )
        return quantized, output_scale
    native = _get_native()
    if native is not None and hasattr(native, "quantize_int8_tensorwise"):
        return native.quantize_int8_tensorwise(x, scale, stochastic_rounding)
    return _ref_quantize_int8_tensorwise(x, scale, stochastic_rounding)


@compile_op("quantize_int8_rowwise", fake_rowwise)
def quantize_int8_rowwise(
    x: torch.Tensor,
    stochastic_rounding: int = 0,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Quantize tensor to INT8 with per-row scales (for activations).

    Args:
        x: Input tensor [..., K] where quantization is per-row.
        stochastic_rounding: Seed for stochastic rounding. Disabled when <= 0.

    Returns:
        Tuple of (quantized_int8, scales):
            - quantized_int8: INT8 tensor with same shape
            - scales: Float32 tensor [..., 1] with per-row scales
    """
    if torch.compiler.is_compiling():
        return torch.ops.omni_xpu.quantize_int8_rowwise(x, stochastic_rounding)
    native = _get_native()
    if native is not None:
        # The fused hot path covers deterministic FP32/FP16/BF16 rowwise input.
        # Preserve the generic native API for explicit stochastic rounding.
        if (
            stochastic_rounding <= 0
            and x.ndim >= 1
            and x.dtype in (torch.float32, torch.float16, torch.bfloat16)
            and hasattr(native, "quantize_int8_rowwise_fused")
        ):
            return native.quantize_int8_rowwise_fused(x)
        if hasattr(native, "quantize_int8_rowwise"):
            return native.quantize_int8_rowwise(x, stochastic_rounding)
    return _ref_quantize_int8_rowwise(x, stochastic_rounding)


@compile_op("fused_silu_mul_quantize_rowwise", fake_silu_mul_rowwise)
def fused_silu_mul_quantize_rowwise(
    x1: torch.Tensor,
    x2: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Fuse ``SiLU(x1) * x2`` with deterministic rowwise INT8 quantization.

    The floating SwiGLU result is not materialized by the native path. The
    returned quantized tensor and row scales can be passed directly to
    :func:`int8_linear_prequantized`.
    """
    if torch.compiler.is_compiling():
        return torch.ops.omni_xpu.fused_silu_mul_quantize_rowwise(x1, x2)
    native = _get_native()
    if native is not None and hasattr(native, "fused_silu_mul_quantize_rowwise"):
        return native.fused_silu_mul_quantize_rowwise(x1, x2)
    return _ref_fused_silu_mul_quantize_rowwise(x1, x2)


@compile_op("fused_swiglu_quantize_rowwise", fake_swiglu_rowwise)
def fused_swiglu_quantize_rowwise(
    input: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Fuse concatenated ``[gate | up]`` SwiGLU with rowwise INT8 quantization."""
    if torch.compiler.is_compiling():
        return torch.ops.omni_xpu.fused_swiglu_quantize_rowwise(input)
    if input.shape[-1] <= 0 or input.shape[-1] % 2:
        raise ValueError("SwiGLU input last dimension must be positive and even")
    native = _get_native()
    if native is not None and hasattr(native, "fused_swiglu_quantize_rowwise"):
        return native.fused_swiglu_quantize_rowwise(input)
    gate, up = input.chunk(2, dim=-1)
    return _ref_fused_silu_mul_quantize_rowwise(gate, up)


@compile_op("fused_gelu_tanh_quantize_rowwise", fake_gelu_rowwise)
def fused_gelu_tanh_quantize_rowwise(
    input: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Fuse tanh-approximate GELU with rowwise INT8 quantization."""
    if torch.compiler.is_compiling():
        return torch.ops.omni_xpu.fused_gelu_tanh_quantize_rowwise(input)
    if input.shape[-1] <= 0:
        raise ValueError("GELU input last dimension must be positive")
    native = _get_native()
    if native is not None and hasattr(native, "fused_gelu_tanh_quantize_rowwise"):
        return native.fused_gelu_tanh_quantize_rowwise(input)
    activated = torch.nn.functional.gelu(input, approximate="tanh")
    return quantize_int8_rowwise(activated)


@compile_op("fused_silu_mul", fake_silu_mul)
def fused_silu_mul(
    x1: torch.Tensor,
    x2: torch.Tensor,
) -> torch.Tensor:
    """Fuse ``SiLU(x1) * x2`` while retaining one floating output tensor.

    This boundary is useful before a required floating transform such as
    ConvRot: it removes the separate SiLU allocation while preserving the
    existing optimized transform implementation.
    """
    if torch.compiler.is_compiling():
        return torch.ops.omni_xpu.fused_silu_mul(x1, x2)
    native = _get_native()
    if native is not None and hasattr(native, "fused_silu_mul"):
        return native.fused_silu_mul(x1, x2)
    return _ref_fused_silu_mul(x1, x2)


@compile_op("dequantize_int8_simple", _meta.int8_dequantize)
def dequantize_int8_simple(
    q: torch.Tensor,
    scale: torch.Tensor,
) -> torch.Tensor:
    """Dequantize INT8 tensor with scale.

    Args:
        q: Quantized INT8 tensor.
        scale: Scale tensor (scalar or broadcastable).

    Returns:
        Dequantized float32 tensor.
    """
    if torch.compiler.is_compiling():
        return torch.ops.omni_xpu.dequantize_int8_simple(q, scale)
    native = _get_native()
    if native is not None and hasattr(native, "dequantize_int8_simple"):
        return native.dequantize_int8_simple(q, scale)
    return _ref_dequantize_int8_simple(q, scale)


@compile_op("dequantize_int8_simple_dtype", _meta.int8_dequantize_dtype)
def dequantize_int8_simple_dtype(
    q: torch.Tensor,
    scale: torch.Tensor,
    out_dtype: torch.dtype = torch.bfloat16,
) -> torch.Tensor:
    """Dequantize INT8 tensor with scale into specified output dtype.

    Args:
        q: Quantized INT8 tensor.
        scale: Scale tensor (scalar or broadcastable).
        out_dtype: Output dtype (float32, float16, or bfloat16).

    Returns:
        Dequantized tensor in specified dtype.
    """
    if torch.compiler.is_compiling():
        return torch.ops.omni_xpu.dequantize_int8_simple_dtype(q, scale, out_dtype)
    native = _get_native()
    if native is not None and hasattr(native, "dequantize_int8_simple_dtype"):
        _dtype_to_code = {torch.float32: 0, torch.float16: 1, torch.bfloat16: 2}
        if out_dtype not in _dtype_to_code:
            raise ValueError(
                f"Unsupported out_dtype: {out_dtype}. Supported: float32, float16, bfloat16"
            )
        return native.dequantize_int8_simple_dtype(q, scale, _dtype_to_code[out_dtype])
    return _ref_dequantize_int8_simple_dtype(q, scale, out_dtype)


@compile_op("mm_int8", _meta.int8_mm)
def mm_int8(
    a: torch.Tensor,
    b: torch.Tensor,
) -> torch.Tensor:
    """INT8 matrix multiplication: C[M,N] = A[M,K] @ B[K,N].

    Uses oneDNN s8×s8→s32 GEMM on XPU for maximum throughput.

    Args:
        a: INT8 tensor [M, K].
        b: INT8 tensor [K, N].

    Returns:
        INT32 tensor [M, N] with accumulated dot products.
    """
    if torch.compiler.is_compiling():
        return torch.ops.omni_xpu.mm_int8(a, b)
    native = _get_native()
    if native is not None and hasattr(native, "mm_int8"):
        return native.mm_int8(a, b)
    return _ref_mm_int8(a, b)


@compile_op("int8_linear", fake_int8_linear)
def int8_linear(
    x: torch.Tensor,
    weight: torch.Tensor,
    weight_scale: torch.Tensor,
    bias: Optional[torch.Tensor] = None,
    out_dtype: Optional[torch.dtype] = None,
    convrot: bool = False,
    convrot_groupsize: int = 256,
    input_act: Optional[str] = None,
) -> torch.Tensor:
    """INT8 linear layer with dynamic activation quantization.

    Quantizes activation per-row, performs INT8 GEMM, rescales output.
    Optionally applies ConvRot (online Hadamard rotation) for improved accuracy.

    Args:
        x: Input tensor [..., K] (fp16/bf16).
        weight: INT8 weight tensor [N, K].
        weight_scale: Weight scale (scalar or per-channel [N] or [N,1]).
        bias: Optional bias tensor [N].
        out_dtype: Output dtype (defaults to x.dtype).
        convrot: If True, apply online activation rotation before quantization.
        convrot_groupsize: Group size for Hadamard rotation (must be power of 4).
        input_act: Optional ``gelu_tanh``, ``swiglu`` or ``situ`` activation
            applied before activation quantization. SwiGLU consumes concatenated
            ``[gate | up]`` halves; SiTU consumes ``[hidden | gate]`` halves.
            Both gated activations halve the input width.

    Returns:
        Result tensor [..., N] in out_dtype.
    """
    if torch.compiler.is_compiling():
        return torch.ops.omni_xpu.int8_linear(x, weight, weight_scale, bias, out_dtype, convrot, convrot_groupsize, input_act)
    if out_dtype is None:
        out_dtype = x.dtype
    width = 2 if input_act in ("swiglu", "situ") else 1
    if input_act not in (None, "none", "gelu_tanh", "swiglu", "situ"):
        _apply_input_act(x, input_act)
    if x.shape[-1] != weight.shape[-1] * width:
        raise ValueError(
            "Input and weight inner dimensions must match after input_act, "
            f"got {x.shape[-1]} and {weight.shape[-1]} with input_act={input_act!r}"
        )
    native = _get_native()
    if native is not None and hasattr(native, "int8_linear"):
        dtype_code = {
            torch.float32: 0,
            torch.float16: 1,
            torch.bfloat16: 2,
        }.get(out_dtype, 2)
        if (input_act == "situ" and x.dtype in (torch.float16, torch.bfloat16)
                and 0 < x.shape[-1] // 2 <= 8192
                and (not convrot or convrot_groupsize in (64, 256))
                and (not convrot or x.shape[-1] // 2 % convrot_groupsize == 0)
                and hasattr(native, "int8_linear_prequantized")):
            from .. import kitchen

            if kitchen.supports_gated_quantize_int8():
                _clear_krea2_activation_cache()
                _clear_bmg_qkv_activation_cache()
                quantized, scale = kitchen.gated_quantize_int8(
                    x, input_act, convrot_groupsize if convrot else 0,
                )
                return native.int8_linear_prequantized(
                    quantized, scale, weight, weight_scale, bias, dtype_code,
                )
        if (
            input_act == "swiglu"
            and not convrot
            and x.dtype in (torch.float16, torch.bfloat16)
            and hasattr(native, "fused_swiglu_quantize_rowwise")
            and hasattr(native, "int8_linear_prequantized")
        ):
            _clear_krea2_activation_cache()
            _clear_bmg_qkv_activation_cache()
            x_int8, x_scale = native.fused_swiglu_quantize_rowwise(x)
            return native.int8_linear_prequantized(
                x_int8,
                x_scale,
                weight,
                weight_scale,
                bias,
                dtype_code,
            )
        if (
            input_act == "gelu_tanh"
            and not convrot
            and _can_fuse_gelu_tanh_quantize(x, native)
        ):
            _clear_krea2_activation_cache()
            _clear_bmg_qkv_activation_cache()
            x_int8, x_scale = native.fused_gelu_tanh_quantize_rowwise(x)
            return native.int8_linear_prequantized(
                x_int8,
                x_scale,
                weight,
                weight_scale,
                bias,
                dtype_code,
            )
        if _can_stream_h3_swiglu(
            x,
            native,
            weight,
            bias,
            out_dtype,
            convrot,
            convrot_groupsize,
            input_act,
        ):
            _clear_krea2_activation_cache()
            _clear_bmg_qkv_activation_cache()
            return _stream_h3_swiglu_int8_linear(
                x,
                native,
                weight,
                weight_scale,
                dtype_code,
            )
        if _can_stream_h3_convrot(
            x,
            native,
            weight,
            bias,
            out_dtype,
            convrot,
            convrot_groupsize,
            input_act,
        ):
            _clear_krea2_activation_cache()
            _clear_bmg_qkv_activation_cache()
            return _stream_h3_convrot_int8_linear(
                x,
                native,
                weight,
                weight_scale,
                dtype_code,
            )
        swiglu_fusion_input = x
        swiglu_output_shape = None
        if (
            input_act == "swiglu"
            and x.ndim == 3
            and x.shape[-1] > 0
            and x.is_contiguous()
            # Native packed row offsets use int32 before splitting gate/up.
            and x.numel() <= 2**31 - 1
            and x.shape[-1] <= 2**31 - 1
        ):
            swiglu_fusion_input = x.view(-1, x.shape[-1])
            swiglu_output_shape = (*x.shape[:-1], x.shape[-1] // 2)
        if _can_fuse_h3_swiglu(
            swiglu_fusion_input,
            native,
            weight,
            convrot,
            convrot_groupsize,
            input_act,
        ):
            x = _apply_h3_swiglu_exact(swiglu_fusion_input, native)
            if swiglu_output_shape is not None:
                x = x.view(swiglu_output_shape)
        else:
            x = _apply_input_act(x, input_act)
        if _can_cache_krea2_int8_convrot(
            x,
            native,
            weight,
            weight_scale,
            bias,
            out_dtype,
            convrot,
            convrot_groupsize,
        ):
            _clear_bmg_qkv_activation_cache()
            x_int8, x_scale = _quantize_krea2_int8_convrot(x, native)
            return native.int8_linear_prequantized(
                x_int8,
                x_scale,
                weight,
                weight_scale,
                bias,
                dtype_code,
            )
        _clear_krea2_activation_cache()
        if _can_cache_int8_convrot_g16_bmg(
            x,
            native,
            weight,
            weight_scale,
            bias,
            out_dtype,
            convrot,
            convrot_groupsize,
        ):
            x_int8, x_scale = _quantize_int8_convrot_g16_bmg_qkv(
                x, native, weight.shape[0]
            )
            return native.int8_linear_prequantized(
                x_int8,
                x_scale,
                weight,
                weight_scale,
                bias,
                dtype_code,
            )
        _clear_bmg_qkv_activation_cache()
        if _can_quantize_int8_convrot_g16_bmg(
            x, native, convrot, convrot_groupsize
        ):
            x_int8, x_scale = native.quantize_int8_convrot_g16_bmg(x)
            return native.int8_linear_prequantized(
                x_int8,
                x_scale,
                weight,
                weight_scale,
                bias,
                dtype_code,
            )
        # Rotate through the native cached Hadamard-matrix implementation.
        if convrot:
            if x.shape[-1] % convrot_groupsize != 0:
                raise ValueError(
                    f"ConvRot group size {convrot_groupsize} does not divide "
                    f"input features {x.shape[-1]}"
                )
            if hasattr(native, "rotate_convrot"):
                x = _native_rotate_convrot(native, x, convrot_groupsize)
            else:
                from ._reference import _build_hadamard, _rotate_activation

                h = _build_hadamard(convrot_groupsize, device=x.device, dtype=x.dtype)
                x = _rotate_activation(x, h, convrot_groupsize)
        if _can_tile_int8_linear(x, native, weight, out_dtype):
            return _tile_int8_linear(
                x,
                native,
                weight,
                weight_scale,
                bias,
                out_dtype,
                dtype_code,
            )
        return native.int8_linear(
            x, weight, weight_scale, bias, dtype_code, False, convrot_groupsize
        )
    _clear_krea2_activation_cache()
    _clear_bmg_qkv_activation_cache()
    x = _apply_input_act(x, input_act)
    return _ref_int8_linear(
        x, weight, weight_scale, bias, out_dtype, convrot, convrot_groupsize
    )


@compile_op("int8_linear_prequantized", fake_prequantized)
def int8_linear_prequantized(
    x_int8: torch.Tensor,
    x_scale: torch.Tensor,
    weight: torch.Tensor,
    weight_scale: torch.Tensor,
    bias: Optional[torch.Tensor] = None,
    out_dtype: torch.dtype = torch.bfloat16,
) -> torch.Tensor:
    """INT8 linear layer for an already rowwise-quantized activation.

    This API does not quantize the activation. It is intended for sharing one
    activation quantization across multiple Linear calls and for consuming the
    output of a fused producer such as SwiGLU-plus-quantize.

    Args:
        x_int8: Rowwise-quantized activation tensor [..., K] in INT8.
        x_scale: One activation scale per flattened input row.
        weight: INT8 weight tensor [N, K].
        weight_scale: Weight scale (scalar or per-channel [N] or [N,1]).
        bias: Optional bias tensor [N].
        out_dtype: Output dtype (float32, float16, or bfloat16).

    Returns:
        Result tensor [..., N] in out_dtype.
    """
    if torch.compiler.is_compiling():
        return torch.ops.omni_xpu.int8_linear_prequantized(x_int8, x_scale, weight, weight_scale, bias, out_dtype)
    dtype_code = {
        torch.float32: 0,
        torch.float16: 1,
        torch.bfloat16: 2,
    }.get(out_dtype)
    if dtype_code is None:
        raise ValueError(
            f"Unsupported out_dtype: {out_dtype}. Supported: "
            "float32, float16, bfloat16"
        )

    _clear_krea2_activation_cache()
    _clear_bmg_qkv_activation_cache()
    native = _get_native()
    if native is not None and hasattr(native, "int8_linear_prequantized"):
        return native.int8_linear_prequantized(
            x_int8,
            x_scale,
            weight,
            weight_scale,
            bias,
            dtype_code,
        )
    return _ref_int8_linear_prequantized(
        x_int8,
        x_scale,
        weight,
        weight_scale,
        bias=bias,
        out_dtype=out_dtype,
    )


def supports_w4a8_linear_prequantized() -> bool:
    """Whether the loaded core can consume grouped packed W4 weights directly."""
    native = _get_native()
    return native is not None and hasattr(native, "w4a8_linear_prequantized")


@compile_op("w4a8_linear_prequantized", fake_w4a8_prequantized)
def w4a8_linear_prequantized(
    x_int8: torch.Tensor,
    x_scale: torch.Tensor,
    packed: torch.Tensor,
    relative_scale: torch.Tensor,
    channel_scale: torch.Tensor,
    codebook: Optional[torch.Tensor] = None,
    bias: Optional[torch.Tensor] = None,
    group_size: int = 16,
    out_dtype: torch.dtype = torch.bfloat16,
) -> torch.Tensor:
    """Compute a grouped W4A8 linear without materializing the decoded weight.

    Each nibble is decoded, multiplied by its group scale, rounded ties-to-even
    and clamped to [-127, 127] before the integer dot product. The existing INT8
    scale-back path supplies output scaling, dtype conversion and bias.
    """
    if torch.compiler.is_compiling():
        return torch.ops.omni_xpu.w4a8_linear_prequantized(
            x_int8, x_scale, packed, relative_scale, channel_scale,
            codebook, bias, group_size, out_dtype,
        )
    dtype_code = {torch.float32: 0, torch.float16: 1, torch.bfloat16: 2}.get(out_dtype)
    if dtype_code is None:
        raise ValueError(f"Unsupported W4A8 output dtype: {out_dtype}")
    native = _get_native()
    if native is None or not hasattr(native, "w4a8_linear_prequantized"):
        raise RuntimeError("native packed W4A8 linear is unavailable")
    _clear_krea2_activation_cache()
    _clear_bmg_qkv_activation_cache()
    return native.w4a8_linear_prequantized(
        x_int8, x_scale, packed, relative_scale, channel_scale,
        codebook, bias, group_size, dtype_code,
    )


@compile_op("int8_linear_shared_input", fake_shared_input)
def int8_linear_shared_input(
    x: torch.Tensor,
    weight1: torch.Tensor,
    weight_scale1: torch.Tensor,
    weight2: torch.Tensor,
    weight_scale2: torch.Tensor,
    bias1: Optional[torch.Tensor] = None,
    bias2: Optional[torch.Tensor] = None,
    out_dtype: Optional[torch.dtype] = None,
    convrot: bool = False,
    convrot_groupsize: int = 256,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Run two INT8 linear projections with one activation quantization.

    ConvRot, when requested, is also applied once and therefore must be shared
    by both weights.
    """
    if torch.compiler.is_compiling():
        return torch.ops.omni_xpu.int8_linear_shared_input(x, weight1, weight_scale1, weight2, weight_scale2, bias1, bias2, out_dtype, convrot, convrot_groupsize)
    _clear_krea2_activation_cache()
    _clear_bmg_qkv_activation_cache()
    if out_dtype is None:
        out_dtype = x.dtype
    dtype_code = {
        torch.float32: 0,
        torch.float16: 1,
        torch.bfloat16: 2,
    }.get(out_dtype)
    if dtype_code is None:
        raise ValueError(
            f"Unsupported out_dtype: {out_dtype}. Supported: "
            "float32, float16, bfloat16"
        )

    native = _get_native()
    if native is not None and hasattr(native, "int8_linear_shared_input"):
        if _can_pair_int8_convrot_g16_bmg(
            x,
            native,
            weight1,
            weight_scale1,
            weight2,
            weight_scale2,
            bias1,
            bias2,
            out_dtype,
            convrot,
            convrot_groupsize,
        ):
            x_int8, x_scale = native.quantize_int8_convrot_g16_bmg(x)
            return native.int8_linear_pair_prequantized(
                x_int8,
                x_scale,
                weight1,
                weight_scale1,
                weight2,
                weight_scale2,
                dtype_code,
            )
        if convrot:
            if x.shape[-1] % convrot_groupsize != 0:
                raise ValueError(
                    f"ConvRot group size {convrot_groupsize} does not divide "
                    f"input features {x.shape[-1]}"
                )
            if hasattr(native, "rotate_convrot"):
                x = _native_rotate_convrot(native, x, convrot_groupsize)
            else:
                from ._reference import _build_hadamard, _rotate_activation

                h = _build_hadamard(
                    convrot_groupsize, device=x.device, dtype=x.dtype
                )
                x = _rotate_activation(x, h, convrot_groupsize)
        return native.int8_linear_shared_input(
            x,
            weight1,
            weight_scale1,
            weight2,
            weight_scale2,
            bias1,
            bias2,
            dtype_code,
        )

    return _ref_int8_linear_shared_input(
        x,
        weight1,
        weight_scale1,
        weight2,
        weight_scale2,
        bias1=bias1,
        bias2=bias2,
        out_dtype=out_dtype,
        convrot=convrot,
        convrot_groupsize=convrot_groupsize,
    )


@compile_op("rotate_convrot", fake_rotate_convrot)
def rotate_convrot(
    x: torch.Tensor,
    group_size: int = 256,
) -> torch.Tensor:
    """Apply the online groupwise Hadamard activation rotation."""
    if torch.compiler.is_compiling():
        return torch.ops.omni_xpu.rotate_convrot(x, group_size)
    if x.shape[-1] % group_size != 0:
        raise ValueError(
            f"features {x.shape[-1]} not divisible by group_size {group_size}"
        )
    native = _get_native()
    if native is not None and hasattr(native, "rotate_convrot"):
        return _native_rotate_convrot(native, x, group_size)

    from ._reference import _build_hadamard, _rotate_activation

    h = _build_hadamard(group_size, device=x.device, dtype=x.dtype)
    return _rotate_activation(x, h, group_size)


@compile_op("quantize_int8_convrot_weight", _meta.convrot_quantize)
def quantize_int8_convrot_weight(
    weight: torch.Tensor,
    group_size: int = 256,
    stochastic_rounding: int = 0,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Offline ConvRot weight rotation followed by per-row INT8 quantization.

    Args:
        weight: Weight tensor [N, K].
        group_size: Hadamard rotation group size (must be power of 4).
        stochastic_rounding: Seed for stochastic rounding.

    Returns:
        Tuple of (rotated_quantized_weight_int8, per_row_scales).
    """
    if torch.compiler.is_compiling():
        return torch.ops.omni_xpu.quantize_int8_convrot_weight(weight, group_size, stochastic_rounding)
    if weight.shape[-1] % group_size != 0:
        raise ValueError(
            f"input features {weight.shape[-1]} not divisible by group_size {group_size}"
        )
    native = _get_native()
    if native is not None and hasattr(native, "quantize_int8_convrot_weight"):
        _prepare_native_convrot_hadamard(native, weight, group_size)
        return native.quantize_int8_convrot_weight(
            weight, group_size, stochastic_rounding
        )
    return _ref_quantize_int8_convrot_weight(weight, group_size, stochastic_rounding)


@compile_op("dequantize_int8_convrot_weight", _meta.convrot_dequantize)
def dequantize_int8_convrot_weight(
    q: torch.Tensor,
    scale: torch.Tensor,
    group_size: int = 256,
) -> torch.Tensor:
    """Dequantize INT8 ConvRot weights and rotate back to original basis.

    Args:
        q: Quantized INT8 weight tensor [N, K].
        scale: Per-row scales [N, 1].
        group_size: Hadamard rotation group size.

    Returns:
        Dequantized weight tensor in float32.
    """
    if torch.compiler.is_compiling():
        return torch.ops.omni_xpu.dequantize_int8_convrot_weight(q, scale, group_size)
    native = _get_native()
    if native is not None and hasattr(native, "dequantize_int8_convrot_weight"):
        _prepare_native_convrot_hadamard(native, q, group_size, fp32=True)
        return native.dequantize_int8_convrot_weight(q, scale, group_size)
    return _ref_dequantize_int8_convrot_weight(q, scale, group_size)


def int8_cache_clear() -> None:
    """Clear cached oneDNN INT8 primitive state."""
    _clear_krea2_activation_cache()
    _clear_bmg_qkv_activation_cache()
    native = _get_native()
    if native is not None and hasattr(native, "int8_cache_clear"):
        native.int8_cache_clear()


def release_onednn_int8_cache() -> int:
    """Flush linked oneDNN primitive state after all XPU work has stopped."""
    if sys.platform != "linux":
        raise RuntimeError("oneDNN INT8 cache release is Linux-only")
    native = _get_native()
    release = getattr(native, "release_onednn_int8_cache", None)
    if release is None:
        raise RuntimeError("native oneDNN INT8 cache release is unavailable")
    for device_index in range(torch.xpu.device_count()):
        torch.xpu.synchronize(device_index)
    _clear_krea2_activation_cache()
    _clear_bmg_qkv_activation_cache()
    return int(release())


def int8_cache_stats() -> dict:
    """Return INT8 primitive cache counters and size."""
    native = _get_native()
    if native is not None and hasattr(native, "int8_cache_stats"):
        hits, misses, size = native.int8_cache_stats()
        return {"hits": hits, "misses": misses, "size": size}
    return {"hits": 0, "misses": 0, "size": 0}


__all__ = [
    "quantize_int8_tensorwise",
    "quantize_int8_rowwise",
    "fused_silu_mul_quantize_rowwise",
    "fused_swiglu_quantize_rowwise",
    "fused_gelu_tanh_quantize_rowwise",
    "fused_silu_mul",
    "dequantize_int8_simple",
    "dequantize_int8_simple_dtype",
    "mm_int8",
    "int8_linear",
    "int8_linear_prequantized",
    "w4a8_linear_prequantized",
    "supports_w4a8_linear_prequantized",
    "int8_linear_shared_input",
    "rotate_convrot",
    "prepare_convrot_hadamard",
    "clear_convrot_hadamard_cache",
    "set_allocation_context_factory",
    "quantize_int8_convrot_weight",
    "dequantize_int8_convrot_weight",
    "int8_cache_clear",
    "release_onednn_int8_cache",
    "int8_cache_stats",
]
